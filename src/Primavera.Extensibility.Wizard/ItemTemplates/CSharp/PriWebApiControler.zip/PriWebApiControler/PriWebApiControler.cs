﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;
$if$ ($targetframeworkversion$ >= 4.5)using System.Threading.Tasks;
$endif$using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;
using Primavera.WebAPI.Integration;

namespace $rootnamespace$
{
	[RoutePrefix("$safeitemrootname$")]
    public class $safeitemrootname$Controller : ApiController
    {
		[Authorize]
        [HttpGet]
        [Route("GetSample")]
        public HttpResponseMessage GetSample()
        {
            try
            {
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);
				
				// Use the product context to get access to all API.
				// ex. ProductContext.MotorLE.Vendas.Documentos.EditaID("");
				
				return response;
            }
            catch (Exception ex)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.BadRequest, ex.Message));
            }
        }
	}
}
