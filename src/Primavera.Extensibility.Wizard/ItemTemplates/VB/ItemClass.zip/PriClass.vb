﻿Imports System
Imports System.Collections.Generic
$if$ ($targetframeworkversion$ >= 3.5)Imports System.Linq
$endif$Imports System.Text
$if$ ($targetframeworkversion$ >= 4.5)Imports System.Threading.Tasks
$endif$Imports Primavera.Extensibility.BusinessEntities
Imports Primavera.Extensibility.$PriModule$.$ModuleType$

Public Class $safeitemrootname$
    Inherits $PriInheritsFrom$

End Class